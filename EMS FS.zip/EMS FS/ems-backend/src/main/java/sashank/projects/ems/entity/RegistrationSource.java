package sashank.projects.ems.entity;

public enum RegistrationSource {
    GITHUB
}
