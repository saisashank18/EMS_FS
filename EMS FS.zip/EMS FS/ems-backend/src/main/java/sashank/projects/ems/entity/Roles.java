package sashank.projects.ems.entity;

import jakarta.persistence.Entity;


public enum Roles {
    ROLE_EMPLOYEE, ROLE_ADMIN, ROLE_MANAGER
}
