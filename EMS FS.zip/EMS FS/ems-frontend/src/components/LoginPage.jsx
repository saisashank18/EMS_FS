import React from 'react'
import { useEffect } from 'react'
const LoginPage = () => {
  return (
    <div>
      <div id='sign-in-div'></div>
    </div>
  )
}

export default LoginPage
